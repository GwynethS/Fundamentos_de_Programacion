﻿using Datos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Presentacion
{
    public partial class DocenteWindow : Window
    {
        private NDocente nDocente = new NDocente();
        private Docente docenteSeleccionado = null;
        public DocenteWindow()
        {
            InitializeComponent();
            MostrarDocentes(nDocente.ListarTodo());
        }

        private void MostrarDocentes(List<Docente> docentes)
        {
            dgDocente.ItemsSource = new List<Docente>();
            dgDocente.ItemsSource = docentes;
        }

        private void btnAgregar_Click(object sender, RoutedEventArgs e)
        {
            if(txtNombre.Text == "" || txtApellido.Text == "" || txtEscuela.Text == "")
            {
                MessageBox.Show("Complete todos los campos.");
                return;
            }

            Docente docente = new Docente
            {
                Nombre = txtNombre.Text,
                Apellido = txtApellido.Text,
                Escuela = txtEscuela.Text
            };

            String mensaje = nDocente.Registrar(docente);
            MessageBox.Show(mensaje);

            MostrarDocentes(nDocente.ListarTodo());

            txtNombre.Text = "";
            txtApellido.Text = "";
            txtEscuela.Text = "";
        }

        private void btnModificar_Click(object sender, RoutedEventArgs e)
        {
            if (docenteSeleccionado == null)
            {
                MessageBox.Show("Seleccione un docente.");
                return;
            }

            if (txtNombre.Text == "" || txtApellido.Text == "" || txtEscuela.Text == "")
            {
                MessageBox.Show("Complete todos los campos.");
                return;
            }

            Docente docente = new Docente
            {
                Id_docente = docenteSeleccionado.Id_docente,
                Nombre = txtNombre.Text,
                Apellido = txtApellido.Text,
                Escuela = txtEscuela.Text
            };

            String mensaje = nDocente.Modificar(docente);
            MessageBox.Show(mensaje);

            MostrarDocentes(nDocente.ListarTodo());

            txtNombre.Text = "";
            txtApellido.Text = "";
            txtEscuela.Text = "";
        }

        private void dgDocente_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            docenteSeleccionado = dgDocente.SelectedItem as Docente;

            if(docenteSeleccionado != null)
            {
                txtNombre.Text = docenteSeleccionado.Nombre;
                txtApellido.Text = docenteSeleccionado.Apellido;
                txtEscuela.Text = docenteSeleccionado.Escuela;
            }
            else
            {
                txtNombre.Text = "";
                txtApellido.Text = "";
                txtEscuela.Text = "";
            }
        }

        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            if(docenteSeleccionado == null)
            {
                MessageBox.Show("Seleccione un docente");
                return;
            }

            String mensaje = nDocente.Eliminar(docenteSeleccionado.Id_docente);
            MessageBox.Show(mensaje);

            MostrarDocentes(nDocente.ListarTodo());
        }

        private void btnBuscarPorEscuela_Click(object sender, RoutedEventArgs e)
        {
            if(txtEscuela.Text == "")
            {
                MessageBox.Show("Escriba una escuela");
                return;
            }
            MostrarDocentes(nDocente.ListarTodoPorEscuela(txtEscuela.Text));
        }

        private void btnSalir_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
