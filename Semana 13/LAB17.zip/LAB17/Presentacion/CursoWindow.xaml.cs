﻿using Datos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Presentacion
{
    public partial class CursoWindow : Window
    {
        private NCurso nCurso = new NCurso();
        private Curso cursoSeleccionado = null;
        public CursoWindow()
        {
            InitializeComponent();
            MostrarCursos(nCurso.ListarTodo());
        }

        private void MostrarCursos(List<Curso> cursos)
        {
            dgCurso.ItemsSource = new List<Curso>();
            dgCurso.ItemsSource = cursos;
        }

        private void btnAgregar_Click(object sender, RoutedEventArgs e)
        {
            if(txtNombre.Text == "")
            {
                MessageBox.Show("Complete todos los campos.");
                return;
            }

            Curso curso = new Curso
            {
                Nombrecurso = txtNombre.Text
            };

            String mensaje = nCurso.Registrar(curso);
            MessageBox.Show(mensaje);

            MostrarCursos(nCurso.ListarTodo());

            txtNombre.Text = "";
        }

        private void btnModificar_Click(object sender, RoutedEventArgs e)
        {
            if (cursoSeleccionado == null)
            {
                MessageBox.Show("Seleccione un curso");
                return;
            }

            if (txtNombre.Text == "")
            {
                MessageBox.Show("Complete los campos.");
                return;
            }

            Curso curso = new Curso
            {
                Id_curso = cursoSeleccionado.Id_curso,
                Nombrecurso = txtNombre.Text
            };

            String mensaje = nCurso.Modificar(curso);
            MessageBox.Show(mensaje);

            MostrarCursos(nCurso.ListarTodo());

            txtNombre.Text = "";
        }

        private void dgCurso_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cursoSeleccionado = dgCurso.SelectedItem as Curso;

            if (cursoSeleccionado != null)
            {
                txtNombre.Text = cursoSeleccionado.Nombrecurso;
            }
            else
            {
                txtNombre.Text = "";
            }
        }

        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            if(cursoSeleccionado == null)
            {
                MessageBox.Show("Seleccione un curso");
                return;
            }

            String mensaje = nCurso.Eliminar(cursoSeleccionado.Id_curso);
            MessageBox.Show(mensaje);

            MostrarCursos(nCurso.ListarTodo());
        }

        private void btnSalir_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
