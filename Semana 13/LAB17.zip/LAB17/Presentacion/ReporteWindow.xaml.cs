﻿using Datos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Presentacion
{
    public partial class ReporteWindow : Window
    {
        private NDocente nDocente = new NDocente();
        private NCurso nCurso = new NCurso();
        public ReporteWindow()
        {
            InitializeComponent();
            MostrarDocentes(nDocente.ListarTodo());
            MostrarEscuelas(nDocente.ListarEscuelas());
            MostrarCursos(nCurso.ListarTodo());
        }

        private void MostrarDocentes(List<Docente> docentes)
        {
            dgDocente.ItemsSource = new List<Docente>();
            dgDocente.ItemsSource = docentes;
        }

        private void MostrarEscuelas(List<String> escuelas)
        {
            cbEscuela.ItemsSource = new List<String>();
            cbEscuela.ItemsSource = escuelas;
        }

        private void MostrarCursos(List<Curso> cursos)
        {
            cbCurso.ItemsSource = new List<Curso>();
            cbCurso.ItemsSource = cursos;

            cbCurso.DisplayMemberPath = "Nombrecurso";
            cbCurso.SelectedValuePath = "Nombrecurso";
        }

        private void btnSalir_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnLimpiar_Click(object sender, RoutedEventArgs e)
        {
            MostrarDocentes(nDocente.ListarTodo());
            cbEscuela.SelectedIndex = -1;
            cbCurso.SelectedIndex = -1;
        }

        private void btnBuscarDocentesxEscuela_Click(object sender, RoutedEventArgs e)
        {
            if(cbEscuela.Text == "")
            {
                MessageBox.Show("Seleccione una escuela.");
                return;
            }

            MostrarDocentes(nDocente.ListarTodoPorEscuela(cbEscuela.SelectedValue.ToString()));
        }

        private void btnBuscarDocentesxCurso_Click(object sender, RoutedEventArgs e)
        {
            if (cbCurso.Text == "")
            {
                MessageBox.Show("Seleccione un curso.");
                return;
            }

            MostrarDocentes(nDocente.ListarTodoPorCurso(cbCurso.SelectedValue.ToString()));
        }
    }
}
