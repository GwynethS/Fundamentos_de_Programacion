﻿using Datos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Presentacion
{
    public partial class DocentexCursoWindow : Window
    {
        private NDocentexCurso nDocentexCurso = new NDocentexCurso();
        private NDocente nDocente = new NDocente();
        private NCurso nCurso = new NCurso();
        public DocentexCursoWindow()
        {
            InitializeComponent();
            MostrarDocentexCursos(nDocentexCurso.ListarTodo());
            MostrarDocentes(nDocente.ListarTodo());
            MostrarCursos(nCurso.ListarTodo());
        }

        private void MostrarDocentexCursos(List<DocentexCurso> lst)
        {
            dgDocentexCurso.ItemsSource = new List<DocentexCurso>();
            dgDocentexCurso.ItemsSource = lst;

            // Obtén las columnas por su nombre
            var cursoColumn = dgDocentexCurso.Columns.SingleOrDefault(c => c.Header.ToString() == "Curso");
            var docenteColumn = dgDocentexCurso.Columns.SingleOrDefault(c => c.Header.ToString() == "Docente");

            // Oculta las columnas si se encontraron
            if (cursoColumn != null)
            {
                cursoColumn.Visibility = Visibility.Collapsed;
            }

            if (docenteColumn != null)
            {
                docenteColumn.Visibility = Visibility.Collapsed;
            }

        }

        private void MostrarDocentes(List<Docente> docentes)
        {
            cbDocente.ItemsSource = new List<Docente>();
            cbDocente.ItemsSource = docentes;
            cbDocente.DisplayMemberPath = "Nombre";
            cbDocente.SelectedValuePath = "Id_docente";
        }

        private void MostrarCursos(List<Curso> cursos)
        {
            cbCurso.ItemsSource = new List<Curso>();
            cbCurso.ItemsSource = cursos;
            cbCurso.DisplayMemberPath = "Nombrecurso";
            cbCurso.SelectedValuePath = "Id_curso";
        }

        private void btnSalir_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnAsignar_Click(object sender, RoutedEventArgs e)
        {
            if(cbCurso.Text == "" || cbDocente.Text == "" || txtSemestre.Text == "")
            {
                MessageBox.Show("Complete todos los campos.");
                return;
            }

            DocentexCurso docentexCurso = new DocentexCurso
            {
                Id_docente = (int)cbDocente.SelectedValue,
                Id_curso = (int)cbCurso.SelectedValue,
                Semestre = txtSemestre.Text
            };

            String mensaje = nDocentexCurso.Asignar(docentexCurso);
            MessageBox.Show(mensaje);

            MostrarDocentexCursos(nDocentexCurso.ListarTodo());
        }
    }
}
