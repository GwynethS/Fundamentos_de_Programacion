﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DDocentexCurso
    {
        public DDocentexCurso() { }
        public String Asignar(DocentexCurso docentexCurso)
        {
            try
            {
                using(var context = new BDEFEntities())
                {
                    context.DocentexCurso.Add(docentexCurso);
                    context.SaveChanges();
                }
                return "Asignado correctamente.";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }

        public List<DocentexCurso> ListarTodo()
        {
            List<DocentexCurso> docentexCursos = new List<DocentexCurso>();
            try
            {
                using(var context = new BDEFEntities())
                {
                    docentexCursos = context.DocentexCurso.ToList();
                }
                return docentexCursos;
            }
            catch(Exception ex)
            {
                return docentexCursos;
            }
        }
    }
}
