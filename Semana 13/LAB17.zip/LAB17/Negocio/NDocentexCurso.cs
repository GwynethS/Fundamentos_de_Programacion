﻿using Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NDocentexCurso
    {
        private DDocentexCurso dDocentexCurso = new DDocentexCurso();
        public NDocentexCurso () { }

        public String Asignar(DocentexCurso docentexCurso)
        {
            return dDocentexCurso.Asignar(docentexCurso);
        }
        public List<DocentexCurso>ListarTodo()
        {
            return dDocentexCurso.ListarTodo();
        }
    }
}
