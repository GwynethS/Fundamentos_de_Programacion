﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gwyneth_Segura_ExamenA
{
    internal class Miembro
    {
        public Miembro() { }
        public String Codigo {  get; set; } 
        public String Nombre { get; set; }
        public int Edad { get; set; }
        public String Genero { get; set; }
    }
}
